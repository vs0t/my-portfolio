﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aarons_wood_exam1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcBttn_Click(object sender, EventArgs e)
        {
            string conferenceName = nameenteredBox.Text;
            int numberOfTickets;
            decimal costPerTicket, budget;

            // Validate number of tickets
            if (!int.TryParse(numberenteredBox.Text, out numberOfTickets))
            {
                MessageBox.Show("Please enter a valid numerical value for the number of tickets.");
                return;
            }

            if (numberOfTickets < 0 || numberOfTickets > 21)
            {
                MessageBox.Show("Please enter a valid number of tickets between 0 and 21.");
                return;
            }

            // Validate cost per ticket
            if (!decimal.TryParse(costenteredBox.Text, out costPerTicket))
            {
                MessageBox.Show("Please enter a valid numerical value for the cost per ticket.");
                return;
            }

            if (costPerTicket <= 0)
            {
                MessageBox.Show("Please enter a valid cost per ticket greater than zero.");
                return;
            }

            // Validate budget
            if (!decimal.TryParse(budgetenteredBox.Text, out budget))
            {
                MessageBox.Show("Please enter a valid numerical value for the budget.");
                return;
            }

            if (budget <= 0)
            {
                MessageBox.Show("Please enter a valid budget greater than zero.");
                return;
            }

            // Calculate total cost
            decimal totalCost = numberOfTickets * costPerTicket;

            // Display outputs
            confBox.Text = conferenceName;
            ticketBox.Text = numberOfTickets.ToString();
            costBox.Text = costPerTicket.ToString("C");
            totalBox.Text = totalCost.ToString("C");

            // Check if total cost exceeds budget
            if (totalCost > budget)
            {
                decimal amountOver = totalCost - budget;
                budgetBox.Text = $"Over Budget by: {amountOver.ToString("C")}";
            }
            else
            {
                budgetBox.Text = "Under Budget";
            }
        }

        private void clearBttn_Click(object sender, EventArgs e)
        {
            // Clear all input and output fields
            nameenteredBox.Text = "";
            numberenteredBox.Text = "";
            costenteredBox.Text = "";
            budgetenteredBox.Text = "";
            confBox.Text = "";
            ticketBox.Text = "";
            costBox.Text = "";
            totalBox.Text = "";
            budgetBox.Text = "";
        }

        private void exitBttn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
