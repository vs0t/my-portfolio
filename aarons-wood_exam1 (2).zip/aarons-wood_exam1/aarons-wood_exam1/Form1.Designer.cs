﻿namespace aarons_wood_exam1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.calcBttn = new System.Windows.Forms.Button();
            this.clearBttn = new System.Windows.Forms.Button();
            this.exitBttn = new System.Windows.Forms.Button();
            this.nameenteredBox = new System.Windows.Forms.TextBox();
            this.numberenteredBox = new System.Windows.Forms.TextBox();
            this.costenteredBox = new System.Windows.Forms.TextBox();
            this.budgetenteredBox = new System.Windows.Forms.TextBox();
            this.budgetBox = new System.Windows.Forms.TextBox();
            this.confBox = new System.Windows.Forms.TextBox();
            this.ticketBox = new System.Windows.Forms.TextBox();
            this.costBox = new System.Windows.Forms.TextBox();
            this.totalBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name of the Conference:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number of Tickets:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Cost per single Ticket:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Budget Allocated:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Are you over budget?:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Conference Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total Cost Per Ticket:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(1, 273);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Total Cost:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(208, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Number of tickets purchased:";
            // 
            // calcBttn
            // 
            this.calcBttn.BackColor = System.Drawing.Color.Plum;
            this.calcBttn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.calcBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcBttn.Location = new System.Drawing.Point(39, 319);
            this.calcBttn.Name = "calcBttn";
            this.calcBttn.Size = new System.Drawing.Size(137, 45);
            this.calcBttn.TabIndex = 9;
            this.calcBttn.Text = "CALCUALTE";
            this.calcBttn.UseVisualStyleBackColor = false;
            this.calcBttn.Click += new System.EventHandler(this.calcBttn_Click);
            // 
            // clearBttn
            // 
            this.clearBttn.BackColor = System.Drawing.Color.Pink;
            this.clearBttn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clearBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBttn.Location = new System.Drawing.Point(182, 319);
            this.clearBttn.Name = "clearBttn";
            this.clearBttn.Size = new System.Drawing.Size(137, 45);
            this.clearBttn.TabIndex = 10;
            this.clearBttn.Text = "CLEAR";
            this.clearBttn.UseVisualStyleBackColor = false;
            this.clearBttn.Click += new System.EventHandler(this.clearBttn_Click);
            // 
            // exitBttn
            // 
            this.exitBttn.BackColor = System.Drawing.Color.Red;
            this.exitBttn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exitBttn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBttn.Location = new System.Drawing.Point(325, 319);
            this.exitBttn.Name = "exitBttn";
            this.exitBttn.Size = new System.Drawing.Size(137, 45);
            this.exitBttn.TabIndex = 11;
            this.exitBttn.Text = "EXIT";
            this.exitBttn.UseVisualStyleBackColor = false;
            this.exitBttn.Click += new System.EventHandler(this.exitBttn_Click);
            // 
            // nameenteredBox
            // 
            this.nameenteredBox.Location = new System.Drawing.Point(171, 8);
            this.nameenteredBox.Name = "nameenteredBox";
            this.nameenteredBox.Size = new System.Drawing.Size(205, 20);
            this.nameenteredBox.TabIndex = 12;
            // 
            // numberenteredBox
            // 
            this.numberenteredBox.Location = new System.Drawing.Point(139, 41);
            this.numberenteredBox.Name = "numberenteredBox";
            this.numberenteredBox.Size = new System.Drawing.Size(205, 20);
            this.numberenteredBox.TabIndex = 13;
            // 
            // costenteredBox
            // 
            this.costenteredBox.Location = new System.Drawing.Point(156, 74);
            this.costenteredBox.Name = "costenteredBox";
            this.costenteredBox.Size = new System.Drawing.Size(205, 20);
            this.costenteredBox.TabIndex = 14;
            // 
            // budgetenteredBox
            // 
            this.budgetenteredBox.Location = new System.Drawing.Point(120, 105);
            this.budgetenteredBox.Name = "budgetenteredBox";
            this.budgetenteredBox.Size = new System.Drawing.Size(205, 20);
            this.budgetenteredBox.TabIndex = 15;
            // 
            // budgetBox
            // 
            this.budgetBox.Location = new System.Drawing.Point(171, 140);
            this.budgetBox.Name = "budgetBox";
            this.budgetBox.Size = new System.Drawing.Size(205, 20);
            this.budgetBox.TabIndex = 16;
            // 
            // confBox
            // 
            this.confBox.Location = new System.Drawing.Point(156, 170);
            this.confBox.Name = "confBox";
            this.confBox.Size = new System.Drawing.Size(205, 20);
            this.confBox.TabIndex = 17;
            // 
            // ticketBox
            // 
            this.ticketBox.Location = new System.Drawing.Point(224, 202);
            this.ticketBox.Name = "ticketBox";
            this.ticketBox.Size = new System.Drawing.Size(205, 20);
            this.ticketBox.TabIndex = 18;
            // 
            // costBox
            // 
            this.costBox.Location = new System.Drawing.Point(171, 236);
            this.costBox.Name = "costBox";
            this.costBox.Size = new System.Drawing.Size(205, 20);
            this.costBox.TabIndex = 19;
            // 
            // totalBox
            // 
            this.totalBox.Location = new System.Drawing.Point(100, 269);
            this.totalBox.Name = "totalBox";
            this.totalBox.Size = new System.Drawing.Size(205, 20);
            this.totalBox.TabIndex = 20;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 389);
            this.Controls.Add(this.totalBox);
            this.Controls.Add(this.costBox);
            this.Controls.Add(this.ticketBox);
            this.Controls.Add(this.confBox);
            this.Controls.Add(this.budgetBox);
            this.Controls.Add(this.budgetenteredBox);
            this.Controls.Add(this.costenteredBox);
            this.Controls.Add(this.numberenteredBox);
            this.Controls.Add(this.nameenteredBox);
            this.Controls.Add(this.exitBttn);
            this.Controls.Add(this.clearBttn);
            this.Controls.Add(this.calcBttn);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Ticket Price Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button calcBttn;
        private System.Windows.Forms.Button clearBttn;
        private System.Windows.Forms.Button exitBttn;
        private System.Windows.Forms.TextBox nameenteredBox;
        private System.Windows.Forms.TextBox numberenteredBox;
        private System.Windows.Forms.TextBox costenteredBox;
        private System.Windows.Forms.TextBox budgetenteredBox;
        private System.Windows.Forms.TextBox budgetBox;
        private System.Windows.Forms.TextBox confBox;
        private System.Windows.Forms.TextBox ticketBox;
        private System.Windows.Forms.TextBox costBox;
        private System.Windows.Forms.TextBox totalBox;
    }
}

